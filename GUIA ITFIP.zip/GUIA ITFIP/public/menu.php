<ul class="nav flex-column">
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2 active" aria-current="page" href="inicio.php">
                <svg class="bi"><use xlink:href="#house-fill"/></svg>
                inicio
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="prematricula.php">
                <svg class="bi"><use xlink:href="#file-earmark"/></svg>
                PREMATRICULA
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="matricula.php">
                <svg class="bi"><use xlink:href="#cart"/></svg>
                MATRICULA FINANCIERA
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="matriculaind.php">
                <svg class="bi"><use xlink:href="#people"/></svg>
                MATRICULA INDIVIDUAL
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="registro.php#">
                <svg class="bi"><use xlink:href="#graph-up"/></svg>
                REGISTRO DE NOTAS
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link d-flex align-items-center gap-2" href="notas.php">
                <svg class="bi"><use xlink:href="#puzzle"/></svg>
                SEMAFORO DE NOTAS
              </a>
            </li>
          </ul>